import {Component,OnInit} from '@angular/core';
import {FormsModule,NgForm }  from '@angular/forms';
import {Mobile} from './employee.component';
import {Myservice} from './myservice'
@Component({
    selector:"my-form",
    templateUrl:'./myform.component.html',
    providers :[Myservice]
})
export class MyForm implements OnInit{													//Myform class
    mob:Mobile;
    mob2:number;
    searchResult:string = null;
    searchResultMobile:Mobile = null;
    mobList:Mobile[]=[];
    newMobList:any[];
    constructor(private mser:Myservice){
        this.mob ={mobId:0,mobName:"",mobPrice:0};
    }
    ngOnInit(){
        //this.mobList= this.mser.getAllMob();
        this.mser.getAllMob().subscribe(result=>this.mobList=result);
    }
    submitData(frm1:NgForm):void{
        let mobid =frm1.controls['txtMobId'].value;
        let mobname =frm1.controls['txtMobName'].value;
        let mobprice =frm1.controls['txtMobPrice'].value;
        let e = new Mobile(mobid,mobname,mobprice);
        this.mobList.push(e);
        }
         sortId(){
        this.mobList.sort(function(a,b){return a.mobId-b.mobId});
        }
           sortName(){
        this.mobList.sort(function(a,b){
            if(a.mobName<b.mobName)
            return -1;
        else if(a.mobName>b.mobName)   
            return 1;   
            else return 0;
        });
        }
        
         id3(){
        this.mobList.sort(function(a,b){return a.mobPrice-b.mobPrice});
        }
        
  deleteId(mobId:any){
  //console.log(empNo);
    for(var i=0;i<this.mobList.length;i++)
    {
        if(this.mobList[i]["mobId"]==mobId)    
  this.mobList.splice(i,1);
  }
    }
  
    
    find(id:number):string{
        let yes:string = "This ID Exists";
        let no:string = "This ID does not Exist."
        
        let len:number = this.mobList.length;
        let i:number = 0;
        let flag:number = 0;
        while(len!=0 && flag!=1)
        {
            if(this.mobList[i].mobId == id){flag=1;}
            i++;
            len--;
        }
        
        
        if(flag==1){this.searchResultMobile = this.mobList[i-1]; return yes; }
        else {this.searchResultMobile = null; return no;}
    }
    
    submitData2(frm2:NgForm):void{
        let id = frm2.controls['txtMobId2'].value;
        //this.mobList.pop()
        console.log(this.find(id));
        this.searchResult = this.find(id);
    }
    
    updateData1(frm1:NgForm):void{
        let mobid =frm1.controls['txtMobId'].value;
  			
  			this.deleteId(mobid);
        
        let mobname =frm1.controls['txtMobName'].value;
        let mobprice =frm1.controls['txtMobPrice'].value;
        let e = new Mobile(mobid,mobname,mobprice);
        this.mobList.push(e);
        }
    
}