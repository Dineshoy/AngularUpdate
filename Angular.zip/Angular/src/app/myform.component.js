"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var employee_component_1 = require("./employee.component");
var myservice_1 = require("./myservice");
var MyForm = (function () {
    function MyForm(mser) {
        this.mser = mser;
        this.searchResult = null;
        this.searchResultMobile = null;
        this.mobList = [];
        this.mob = { mobId: 0, mobName: "", mobPrice: 0 };
    }
    MyForm.prototype.ngOnInit = function () {
        var _this = this;
        //this.mobList= this.mser.getAllMob();
        this.mser.getAllMob().subscribe(function (result) { return _this.mobList = result; });
    };
    MyForm.prototype.submitData = function (frm1) {
        var mobid = frm1.controls['txtMobId'].value;
        var mobname = frm1.controls['txtMobName'].value;
        var mobprice = frm1.controls['txtMobPrice'].value;
        var e = new employee_component_1.Mobile(mobid, mobname, mobprice);
        this.mobList.push(e);
    };
    MyForm.prototype.sortId = function () {
        this.mobList.sort(function (a, b) { return a.mobId - b.mobId; });
    };
    MyForm.prototype.sortName = function () {
        this.mobList.sort(function (a, b) {
            if (a.mobName < b.mobName)
                return -1;
            else if (a.mobName > b.mobName)
                return 1;
            else
                return 0;
        });
    };
    MyForm.prototype.id3 = function () {
        this.mobList.sort(function (a, b) { return a.mobPrice - b.mobPrice; });
    };
    MyForm.prototype.deleteId = function (mobId) {
        //console.log(empNo);
        for (var i = 0; i < this.mobList.length; i++) {
            if (this.mobList[i]["mobId"] == mobId)
                this.mobList.splice(i, 1);
        }
    };
    MyForm.prototype.find = function (id) {
        var yes = "This ID Exists";
        var no = "This ID does not Exist.";
        var len = this.mobList.length;
        var i = 0;
        var flag = 0;
        while (len != 0 && flag != 1) {
            if (this.mobList[i].mobId == id) {
                flag = 1;
            }
            i++;
            len--;
        }
        if (flag == 1) {
            this.searchResultMobile = this.mobList[i - 1];
            return yes;
        }
        else {
            this.searchResultMobile = null;
            return no;
        }
    };
    MyForm.prototype.submitData2 = function (frm2) {
        var id = frm2.controls['txtMobId2'].value;
        //this.mobList.pop()
        console.log(this.find(id));
        this.searchResult = this.find(id);
    };
    MyForm.prototype.updateData1 = function (frm1) {
        var mobid = frm1.controls['txtMobId'].value;
        this.deleteId(mobid);
        var mobname = frm1.controls['txtMobName'].value;
        var mobprice = frm1.controls['txtMobPrice'].value;
        var e = new employee_component_1.Mobile(mobid, mobname, mobprice);
        this.mobList.push(e);
    };
    return MyForm;
}());
MyForm = __decorate([
    core_1.Component({
        selector: "my-form",
        templateUrl: './myform.component.html',
        providers: [myservice_1.Myservice]
    }),
    __metadata("design:paramtypes", [myservice_1.Myservice])
], MyForm);
exports.MyForm = MyForm;
